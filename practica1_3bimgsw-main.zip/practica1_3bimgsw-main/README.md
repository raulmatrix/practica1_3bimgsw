# practica1_3bimgsw
